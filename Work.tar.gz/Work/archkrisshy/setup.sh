#!/bin/sh
#github-action genshdoc
#
# step1
#ArchKrisshy
#Automated Arch Linux Installer
#Code by KrisshyDesign @Indonesia
#
######################################################################################
setfont ter-v22n
time_zone="$(curl -fsSL https://ipapi.co/timezone)"
ip_address="$(curl -fsSL ifconfig.io)"
############ REPLACE THE NVME0N1P123 FOR CHANGE YOUR DISK TYPE #######################
efi_partition="sda1"
boot_partition="sda2"
swap_partition="sda3"
root_partition="sda4"
#home_partition="nvme0n1p3" ### add "#" on the front of this line if not use home partition
######################################################################################
pacstrap_install="base base-devel linux linux-firmware linux-headers" 
optional_packages="systemd terminus-font otf-comicshanns-nerd ttf-nerd-fonts-symbols ttf-nerd-fonts-symbols-mono ttf-nerd-fonts-symbols-common awesome-terminal-fonts otf-font-awesome ttf-font-awesome lsd exa nano vim lolcat wget git glibc less fzf bash-language-server bash-completion"
###################################################################################################
echo -ne "
------------------------------------------------------------------------------------
 █████╗ ██████╗  ██████╗██╗  ██╗██╗  ██╗██████╗ ██╗███████╗███████╗██╗  ██╗██╗   ██╗
██╔══██╗██╔══██╗██╔════╝██║  ██║██║ ██╔╝██╔══██╗██║██╔════╝██╔════╝██║  ██║╚██╗ ██╔╝
███████║██████╔╝██║     ███████║█████╔╝ ██████╔╝██║███████╗███████╗███████║ ╚████╔╝
██╔══██║██╔══██╗██║     ██╔══██║██╔═██╗ ██╔══██╗██║╚════██║╚════██║██╔══██║  ╚██╔╝
██║  ██║██║  ██║╚██████╗██║  ██║██║  ██╗██║  ██║██║███████║███████║██║  ██║   ██║
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝
------------------------------------------------------------------------------------
                            Automated Arch Linux Installer
------------------------------------------------------------------------------------
                           Code by KrisshyDesign @Indonesia
------------------------------------------------------------------------------------
"
###################################################################################################
superuser_check() {
    if [[ "$(id -u)" != "0" ]]; then
        echo -ne "Access Denied! This script must be run under the superuser!\n"
        exit 0
    fi
}

archlinux_check() {
    if [[ ! -e /etc/arch-release ]]; then
        echo -ne "Access Denied! This script must be run in Arch Linux!\n"
        exit 0
    fi
}

pacman_check() {
    if [[ -f /var/lib/pacman/db.lck ]]; then
        echo "Access Denied! Pacman is locked."
        echo -ne "If not running delete /var/lib/pacman/db.lck.\n"
        exit 0
    fi
}

docker_check() {
    if awk -F/ '$2 == "docker"' /proc/self/cgroup | read -r; then
        echo -ne "Access Denied! Docker container is not supported (at the moment)\n"
        exit 0
    elif [[ -f /.dockerenv ]]; then
        echo -ne "Access Denied! Docker container is not supported (at the moment)\n"
        exit 0
    fi
}

background_checks() {
    superuser_check
    archlinux_check
    pacman_check
    docker_check
}

logo () {
#
echo -ne "
------------------------------------------------------------------------------------
 █████╗ ██████╗  ██████╗██╗  ██╗██╗  ██╗██████╗ ██╗███████╗███████╗██╗  ██╗██╗   ██╗
██╔══██╗██╔══██╗██╔════╝██║  ██║██║ ██╔╝██╔══██╗██║██╔════╝██╔════╝██║  ██║╚██╗ ██╔╝
███████║██████╔╝██║     ███████║█████╔╝ ██████╔╝██║███████╗███████╗███████║ ╚████╔╝
██╔══██║██╔══██╗██║     ██╔══██║██╔═██╗ ██╔══██╗██║╚════██║╚════██║██╔══██║  ╚██╔╝
██║  ██║██║  ██║╚██████╗██║  ██║██║  ██╗██║  ██║██║███████║███████║██║  ██║   ██║
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝
------------------------------------------------------------------------------------
                          Automated Arch Linux Installer
------------------------------------------------------------------------------------
                         Code by KrisshyDesign @Indonesia
------------------------------------------------------------------------------------
             Enjoy your Coffee this progress may take a several minutes
------------------------------------------------------------------------------------
"
echo
#
}

# Added this from Archwiki https://wiki.archlinux.org/title/System_time
timezone () {
echo -ne "
System detected your Timezone & IP Adrress to be : \n \n '$time_zone' \n '$ip_address' \n \n"
echo "Prepared the Installation ..." && sleep 5
echo "continue in 10 Seconds ..." && sleep 1
echo "Continue in 9 Seconds ..." && sleep 1
echo "Continue in 8 Seconds ..." && sleep 1
echo "Continue in 7 Seconds ..." && sleep 1
echo "continue in 6 Seconds ..." && sleep 1
echo "continue in 5 Seconds ..." && sleep 1
echo "Continue in 4 Seconds ..." && sleep 1
echo "Continue in 3 Seconds ..." && sleep 1
echo "Continue in 2 Seconds ..." && sleep 1
echo "Continue in 1 Second ..." && sleep 1
echo
echo
echo "Here we Go ...." && sleep 1
echo
echo
}


######################################################################################
# Start from here
######################################################################################
clear
clear
clear
echo -ne "
------------------------------------------------------------------------------------
 █████╗ ██████╗  ██████╗██╗  ██╗██╗  ██╗██████╗ ██╗███████╗███████╗██╗  ██╗██╗   ██╗
██╔══██╗██╔══██╗██╔════╝██║  ██║██║ ██╔╝██╔══██╗██║██╔════╝██╔════╝██║  ██║╚██╗ ██╔╝
███████║██████╔╝██║     ███████║█████╔╝ ██████╔╝██║███████╗███████╗███████║ ╚████╔╝
██╔══██║██╔══██╗██║     ██╔══██║██╔═██╗ ██╔══██╗██║╚════██║╚════██║██╔══██║  ╚██╔╝
██║  ██║██║  ██║╚██████╗██║  ██║██║  ██╗██║  ██║██║███████║███████║██║  ██║   ██║
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝
------------------------------------------------------------------------------------
                            Automated Arch Linux Installer
------------------------------------------------------------------------------------
                           Code by KrisshyDesign @Indonesia
------------------------------------------------------------------------------------
"
echo -ne "
------------------------------------------------------------------------------------
     Warning!!! Make sure you has setting the partition before run this script
------------------------------------------------------------------------------------
"
echo
background_checks
echo -ne "Are you has setting up the partition? \n
press Enter to continue or Ctrl + c to exit and setting the partition"
read
umount --recursive /mnt
clear
logo
echo
echo -ne "
------------------------------------------------------------------------------------
                       Getting mirrorlist from Server Krisshy
------------------------------------------------------------------------------------
"
sleep 1
cp /etc/pacman.d/mirrorlist /etc/pacman.d/mirrorlist.backup
curl -o /etc/pacman.d/mirrorlist https://raw.githubusercontent.com/serverkrisshy/setup-archkrisshy/main/mirrorlist
echo
echo -ne "
------------------------------------------------------------------------------------
                     Updating keyring for optimize installation
------------------------------------------------------------------------------------
"
sleep 1
echo
pacman-key --init
pacman-key --populate archlinux
pacman -Sy archlinux-keyring pacman-mirrorlist --noconfirm --needed
clear
logo
echo
echo -ne "
------------------------------------------------------------------------------------
                        Format & Mounting selected partition
------------------------------------------------------------------------------------
"
sleep 3
echo
mkfs.fat -F32 /dev/$efi_partition
mkfs.ext4 /dev/$boot_partition
mkswap /dev/$swap_partition
mkfs.ext4 /dev/$root_partition
#mkfs.ext4 /dev/$home_partition
mount /dev/$root_partition /mnt
mkdir -p /mnt/boot
mount /dev/$boot_partition /mnt/boot
mkdir -p /mnt/boot/EFI
mount /dev/$efi_partition /mnt/boot/EFI
swapon /dev/$swap_partition
#mkdir -p /mnt/home
#mount /dev/$home_partition /mnt/home
lsblk
echo
echo
echo -ne "Is this correct? \n
if not press Ctrl + c to exit \n
Enter to continue"
read
echo
clear
logo
echo -ne "
------------------------------------------------------------------------------------
                        Installing base system to this Machine
------------------------------------------------------------------------------------
"
sleep 3
echo
pacstrap /mnt $pacstrap_install $optional_packages --noconfirm --needed
echo
curl -s -o /mnt/root/arch-chroot-setup.sh https://raw.githubusercontent.com/serverkrisshy/setup-archkrisshy/main/arch-chroot-setup.sh
chmod 755 /mnt/root/arch-chroot-setup.sh
echo
genfstab -U /mnt >> /mnt/etc/fstab
echo "
  Generated fstab file:
"
cat /mnt/etc/fstab
echo
read -p "Is this correct ? "
arch-chroot /mnt ./root/arch-chroot-setup.sh
